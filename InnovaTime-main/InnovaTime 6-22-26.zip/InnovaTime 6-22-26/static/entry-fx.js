/* Entry FX — the extra polish on New Entry / Edit Entry (see entry-fx.css).
   Reads the form, never changes it: what gets saved is exactly as before. */
(function () {
  var form = document.getElementById('entry-form') || document.getElementById('edit-form');
  if (!form) return;
  var card = form.closest('.card');
  var page = card.parentElement;
  page.classList.add('fx-stage');
  card.classList.add('fx-card');

  var save = form.querySelector('button[type="submit"].btn-primary');
  if (save) save.classList.add('fx-save');

  // Live read-back above the buttons
  var receipt = document.createElement('div');
  receipt.className = 'fx-receipt';
  receipt.setAttribute('aria-hidden', 'true');
  var divider = form.querySelector('.divider');
  form.insertBefore(receipt, divider ? divider.nextSibling : save && save.parentElement);

  function codeOf(inputId, hiddenId) {
    var hidden = document.getElementById(hiddenId);
    var input = document.getElementById(inputId);
    if (!hidden || !hidden.value || !input) return '';
    return input.value.split(' — ')[0].trim();
  }
  function chip(text, cls) {
    var s = document.createElement('span');
    s.className = 'fx-chip ' + cls;
    s.textContent = text;
    return s;
  }
  var last = '';
  function render() {
    var client = codeOf('client-search', 'client_id');
    var act = codeOf('activity-search', 'activity_code_id');
    var isPrt = document.getElementById('is_prt').value === '1';
    var amt = isPrt ? document.getElementById('dollar_amount').value : document.getElementById('hours').value;
    var num = parseFloat(amt);
    var dateEl = form.querySelector('input[name="entry_date"]');
    var d = dateEl && dateEl.value ? new Date(dateEl.value + 'T00:00') : null;
    var key = [client, act, amt, isPrt, dateEl && dateEl.value].join('|');
    if (key === last) return;
    last = key;

    receipt.textContent = '';
    if (!client && !act && !(num > 0)) {
      receipt.textContent = 'Your entry will show here as you fill it in';
      receipt.classList.remove('is-ready');
      if (save) save.classList.remove('is-ready');
      return;
    }
    if (client) receipt.appendChild(chip(client, 'is-client'));
    if (act) receipt.appendChild(chip(act, 'is-act'));
    if (num > 0) {
      var strong = document.createElement('strong');
      strong.textContent = isPrt ? '$' + num.toFixed(2) : num + (num === 1 ? ' hour' : ' hours');
      receipt.appendChild(strong);
    }
    if (d) {
      var when = document.createElement('span');
      when.textContent = 'on ' + d.toLocaleDateString(undefined, { weekday: 'short', month: 'numeric', day: 'numeric' });
      receipt.appendChild(when);
    }
    var ready = !!(client && act && num > 0);
    receipt.classList.toggle('is-ready', ready);
    if (save) save.classList.toggle('is-ready', ready);
  }
  ['input', 'change', 'keyup', 'focusout', 'mouseup'].forEach(function (ev) {
    form.addEventListener(ev, function () { setTimeout(render, 0); });
  });
  // The pickers set their hidden fields from script, which fires no events
  new MutationObserver(function () { setTimeout(render, 0); })
    .observe(form, { subtree: true, attributes: true, attributeFilter: ['class'] });
  render();

  // A little confetti when an entry was just saved
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var ok = document.querySelector('.toast-success');
  if (!ok || reduce) return;
  setTimeout(function () {
    var r = ok.getBoundingClientRect();
    var box = document.createElement('div');
    box.className = 'fx-confetti';
    box.style.left = (r.left + 22) + 'px';
    box.style.top = (r.top + r.height / 2) + 'px';
    var colors = ['#005CB9', '#7AC143', '#4a94ff', '#3f8a17', '#f5c451'];
    for (var i = 0; i < 28; i++) {
      var a = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI * 1.4;
      var dist = 80 + Math.random() * 160;
      var p = document.createElement('span');
      p.style.width = (5 + Math.random() * 5) + 'px';
      p.style.height = (7 + Math.random() * 8) + 'px';
      p.style.background = colors[i % colors.length];
      p.style.setProperty('--dx', Math.round(Math.cos(a) * dist) + 'px');
      p.style.setProperty('--dy', Math.round(Math.sin(a) * dist + 90) + 'px');
      p.style.setProperty('--rot', Math.round(Math.random() * 720 - 360) + 'deg');
      p.style.setProperty('--dur', (900 + Math.random() * 700) + 'ms');
      p.style.setProperty('--delay', Math.round(Math.random() * 120) + 'ms');
      box.appendChild(p);
    }
    document.body.appendChild(box);
    setTimeout(function () { box.remove(); }, 2200);
  }, 350);
})();
